---
name: Magellan Professional Instrument
colors:
  surface: '#081425'
  surface-dim: '#081425'
  surface-bright: '#2f3a4c'
  surface-container-lowest: '#040e1f'
  surface-container-low: '#111c2d'
  surface-container: '#152031'
  surface-container-high: '#1f2a3c'
  surface-container-highest: '#2a3548'
  on-surface: '#d8e3fb'
  on-surface-variant: '#c3c6d5'
  inverse-surface: '#d8e3fb'
  inverse-on-surface: '#263143'
  outline: '#8d909e'
  outline-variant: '#434653'
  surface-tint: '#b1c5ff'
  primary: '#b1c5ff'
  on-primary: '#002c70'
  primary-container: '#0047ab'
  on-primary-container: '#a5bdff'
  inverse-primary: '#2559bd'
  secondary: '#ffb77d'
  on-secondary: '#4d2600'
  secondary-container: '#fd8b00'
  on-secondary-container: '#603100'
  tertiary: '#4ae183'
  on-tertiary: '#003919'
  tertiary-container: '#005a2c'
  on-tertiary-container: '#40d87c'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dae2ff'
  primary-fixed-dim: '#b1c5ff'
  on-primary-fixed: '#001946'
  on-primary-fixed-variant: '#00419e'
  secondary-fixed: '#ffdcc3'
  secondary-fixed-dim: '#ffb77d'
  on-secondary-fixed: '#2f1500'
  on-secondary-fixed-variant: '#6e3900'
  tertiary-fixed: '#6bfe9c'
  tertiary-fixed-dim: '#4ae183'
  on-tertiary-fixed: '#00210c'
  on-tertiary-fixed-variant: '#005228'
  background: '#081425'
  on-background: '#d8e3fb'
  surface-variant: '#2a3548'
typography:
  instrument-xl:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  instrument-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  instrument-mobile:
    fontFamily: Geist
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 34px
  data-mono-md:
    fontFamily: JetBrains Mono
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  data-mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
  touch-target-min: 48px
---

## Brand & Style
The design system is built on the philosophy of a "Professional Instrument"—a tool where precision, legibility, and reliability supersede decorative trends. It is engineered for field engineers, surveyors, and navigators who require immediate data recognition under variable lighting conditions.

The aesthetic blends **Minimalism** with **Modern Corporate** efficiency. Every UI element is treated as a functional readout. The interface avoids depth metaphors, instead utilizing a flat, layered architecture that prioritizes high-contrast information density and technical clarity.

## Colors
The palette is optimized for extreme legibility. While the default mode is `dark` (to preserve night vision and reduce glare in low-light field environments), a high-contrast `light` mode is available for direct sunlight visibility.

- **Navigator Blue (#0047AB):** Reserved for primary actions, active navigation states, and brand-identifiable interactions.
- **Warning Orange (#FF8C00):** Used exclusively for system warnings, low-accuracy GNSS alerts, and critical boundary notifications.
- **Success Green (#2ECC71):** Indicates positive GNSS Fix, completed routes, and safe-to-operate status.
- **Neutral Slate (#1E293B):** Serves as the surface color for containers and overlays in dark mode to provide subtle separation from the pure black background.

## Typography
Typography is divided into functional roles:
1.  **Instrument Levels (Geist):** Used for primary numeric readouts like Heading, Distance, and Velocity. These use tight letter-spacing and high weights to ensure they are readable at arm's length.
2.  **Data Levels (JetBrains Mono):** Used for coordinates (Lat/Long), UTC timestamps, and technical metadata. The monospaced nature ensures that jumping numbers do not cause layout shifts.
3.  **Interface Levels (Inter):** Used for menus, labels, and instructional text. 

On mobile devices, the `instrument-xl` scales down to `instrument-mobile` to ensure multi-digit coordinates remain within the viewport.

## Layout & Spacing
The spacing rhythm is based on a strict 4px grid. This design system utilizes a **Fluid Grid** for map overlays and a **Fixed Grid** for sidebar/detail views.

- **Touch Targets:** All interactive elements must maintain a minimum hit area of 48x48px to accommodate gloved use in the field.
- **Navigation Overlays:** HUD-style elements are anchored to the corners of the screen with 16px safe-area margins.
- **Information Density:** Vertical spacing between data rows is kept tight (8px) to maximize the amount of technical data visible without scrolling.

## Elevation & Depth
In keeping with the "Instrument" aesthetic, this design system avoids soft shadows. Depth is communicated through **Tonal Layers** and **Low-contrast Outlines**:

- **Level 0 (Background):** Pure Black (#000000).
- **Level 1 (Surfaces):** Neutral Slate (#1E293B) with a 1px solid border (#334155).
- **Level 2 (Active Overlays):** Navigator Blue (#0047AB) or Slate with a higher contrast border.
- **Separation:** Elements are separated by 1px "Technical Dividers" rather than shadows. Overlays use a subtle backdrop blur (4px) only when floating over map data to maintain legibility of the UI text.

## Shapes
The shape language is "Soft-Technical." A small 4px (Soft) radius is applied to buttons and containers to prevent a primitive brutalist look while maintaining a precise, engineered feel. 

- **Primary Buttons:** 4px radius.
- **Status Pills:** 4px radius (never fully rounded/pill-shaped).
- **Data Cells:** 0px radius (sharp) when stacked in lists to reinforce the grid.

## Components
- **Navigation Overlays:** Semi-transparent (90% opacity) dark panels that float over the map. They feature 1px interior borders and use `instrument-lg` for primary readouts.
- **Status Indicators:** Small rectangular badges for GNSS Fix (e.g., "3D FIX", "RTK FLOAT", "NO FIX"). Color-coded using Success Green or Warning Orange.
- **Buttons:** Large, high-contrast blocks. Primary buttons use Navigator Blue with white text. Secondary buttons use a slate outline.
- **Professional Lists:** Waypoint rows include a monospaced coordinate string on the left and a distance/bearing readout on the right. Rows are separated by 1px hairlines.
- **Bottom Sheets:** Used for detailed waypoint or route information. These slide up to cover 50% or 95% of the screen, using a solid Neutral Slate background to ensure no map detail distracts from data entry.
- **Input Fields:** Stepper-style inputs are preferred for technical data (e.g., manual coordinate entry) to allow precise incrementation.