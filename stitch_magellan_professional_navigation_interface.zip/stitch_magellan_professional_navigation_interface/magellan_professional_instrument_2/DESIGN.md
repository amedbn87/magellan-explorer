---
name: Magellan Professional Instrument
colors:
  surface: '#081425'
  surface-dim: '#081425'
  surface-bright: '#2e3a4c'
  surface-container-lowest: '#030e1f'
  surface-container-low: '#101c2d'
  surface-container: '#152031'
  surface-container-high: '#1f2a3c'
  surface-container-highest: '#2a3548'
  on-surface: '#d7e3fb'
  on-surface-variant: '#c5c6d0'
  inverse-surface: '#d7e3fb'
  inverse-on-surface: '#263143'
  outline: '#8f909a'
  outline-variant: '#44464f'
  surface-tint: '#b1c5ff'
  primary: '#d9e1ff'
  on-primary: '#182e5f'
  primary-container: '#b1c5ff'
  on-primary-container: '#3d5183'
  inverse-primary: '#495d90'
  secondary: '#ffb77d'
  on-secondary: '#4d2600'
  secondary-container: '#6e3d0d'
  on-secondary-container: '#efa971'
  tertiary: '#6afd9c'
  on-tertiary: '#003919'
  tertiary-container: '#49e082'
  on-tertiary-container: '#005f2f'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dae2ff'
  primary-fixed-dim: '#b1c5ff'
  on-primary-fixed: '#001847'
  on-primary-fixed-variant: '#314577'
  secondary-fixed: '#ffdcc3'
  secondary-fixed-dim: '#ffb77d'
  on-secondary-fixed: '#2f1500'
  on-secondary-fixed-variant: '#6b3b0a'
  tertiary-fixed: '#6afe9c'
  tertiary-fixed-dim: '#49e183'
  on-tertiary-fixed: '#00210c'
  on-tertiary-fixed-variant: '#005228'
  background: '#081425'
  on-background: '#d7e3fb'
  surface-variant: '#2a3548'
  sea-data-cyan: '#00f2ff'
  technical-alert-amber: '#ffbf00'
  live-data-pulse: '#4ae183'
  unavailable-data: '#434653'
  environment-wind: '#a5bdff'
  environment-wave: '#7da6ff'
  environment-fishing: '#ff8b00'
  exchange-bluetooth: '#007aff'
  exchange-qr: '#ffffff'
typography:
  instrument-xl:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  instrument-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  instrument-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  instrument-mobile:
    fontFamily: Geist
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 34px
  data-mono-md:
    fontFamily: JetBrains Mono
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  data-mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
  panel-gap: 8px
  touch-target: 48px
---

## Brand & Style

The design system is engineered for high-stakes technical environments—maritime navigation, field surveying, and data exchange. The brand personality is **precise, authoritative, and resilient**, evoking the feeling of a sophisticated bridge instrument rather than a consumer application.

The design style is a hybrid of **Technical Minimalism** and **Glassmorphism**. It utilizes a "HUD-first" (Heads-Up Display) approach where information density is high but visual clutter is low. To support complex dashboard overlays without losing the context of the underlying map, the system employs high-contrast technical surfaces with precision-controlled backdrop blurs. The aesthetic is strictly professional, favoring raw data integrity over decorative elements.

- **Primary Movement:** Technical Minimalism (high-contrast, grid-aligned, data-centric).
- **Secondary Movement:** Glassmorphism (specifically for overlay panels to maintain spatial awareness of maps).
- **Emotional Response:** Confidence, clarity, and industrial-grade reliability.

## Colors

The palette is anchored in a deep **Dark Slate (#081425)** to preserve night vision and provide a high-contrast base for technical readouts. 

### Semantic Logic
- **Marine Data (Cyan):** Used specifically for sea conditions, hydrographic data, and depth soundings.
- **Technical Alerts (Amber):** A non-critical but urgent state for system warnings and sensor recalibration.
- **Status Contrast:** 'Live Data' utilizes the tertiary green with a glowing pulse effect, while 'Unavailable Data' is rendered in a desaturated, low-contrast `outline-variant` to indicate sensor loss.
- **Environmental Indicators:** Specific hues are assigned to Wind (Light Blue), Wave (Medium Blue), and Fishing Activity (Orange) to allow for rapid peripheral recognition on a busy dashboard.
- **Exchange States:** QR and Bluetooth workflows use high-luminance markers to guide the eye during the physical-to-digital transition.

## Typography

The typography system prioritizes **readability at a distance** and **data stability**.

1.  **Geist (Display/Readouts):** Used for large-scale numerical values. The high X-height and tight tracking ensure that multi-digit headings or coordinates remain legible even in vibrating environments.
2.  **JetBrains Mono (Technical Labels):** Used for all coordinates, environmental indicators, and system metadata. The monospaced nature prevents "shimmer" or layout shifting when values update rapidly (e.g., wind speed or depth).
3.  **Inter (UI/Body):** Used for instructional text, menus, and exchange workflow descriptions.

On mobile devices, `instrument-xl` must automatically scale to `instrument-mobile` to prevent horizontal clipping of coordinate strings.

## Layout & Spacing

This design system uses a **Fluid Grid** for the primary map canvas and a **Modular Overlay System** for technical panels.

- **Grid Logic:** A 4px baseline grid governs all internal component spacing.
- **Overlay Panels:** Dashboard widgets are docked to the edges with a 16px margin. In complex workflows (like Bluetooth pairing), panels should center-align but never exceed 400px in width on desktop to maintain map visibility.
- **Technical Density:** Vertical padding in data lists is set to 8px (`2x unit`) to maximize information per screen.
- **Safety Zones:** Interactive components must maintain a 48px touch target to accommodate gloved operation in maritime or field conditions.

## Elevation & Depth

Hierarchy is established through **optical layering** and **translucency** rather than traditional drop shadows.

- **Level 0 (Base):** The map or chart layer.
- **Level 1 (Dashboard Overlays):** High-contrast "Glass" surfaces. These use a 1px `outline-variant` border, a 60% opacity fill of `surface-container`, and a heavy 20px backdrop blur to ensure text remains legible regardless of the map detail beneath it.
- **Level 2 (Active States/Alerts):** Solid, opaque surfaces (`surface-bright`) with a colored top-border (e.g., Amber for alerts) to pull the user's focus.
- **Exchange Overlays:** During QR scanning or pairing, the background is dimmed using a 40% black overlay, and the primary interaction card uses a solid `surface-container-highest` to emphasize security.

## Shapes

The shape language is **"Soft-Technical."** We use a restrained **Soft (4px)** corner radius to provide a modern, manufactured feel without the friendliness of consumer-grade rounded UI.

- **Containers & Panels:** 4px radius.
- **Scanning Squares (QR):** 8px radius (rounded-lg) to visually differentiate from standard data containers.
- **Data Cells:** 0px (Sharp) when stacked in a vertical list to create a seamless "technical tape" appearance.
- **Status Pills:** 4px radius—never use full pill-rounding, as it conflicts with the "Instrument" aesthetic.

## Components

- **Technical Overlays:** Must use the backdrop-blur style. Headers should include the environmental indicator color as a 2px top-accent line.
- **Environmental Badges:** Small badges using `label-caps` on a high-contrast background (e.g., Cyan for Sea). They must include a 1px border of the same hue for maximum vibrance.
- **Exchange Panels:** For Bluetooth/QR, use a centered modal with a solid background. Provide a clear "Scanning" state using a pulsing `exchange-bluetooth` glow effect.
- **Data Rows:** 'Live' rows feature a 2px green left-accent. 'Unavailable' rows use 40% opacity for all text and icons.
- **Buttons:** Large, blocky, and high-contrast. Primary actions use the `primary` blue; destructive or critical actions use `error` red. Outline buttons should be used for secondary map toggles.
- **Input Fields:** For coordinate entry, use monospaced fonts and high-contrast borders. Every input should have a dedicated "Clear" or "Reset" icon for rapid correction in the field.