import { z } from "zod";
import type { LocationPayloadV1 } from "./payload-types";

/**
 * ONE versioned payload format shared by every transport (QR, BT, Wi-Fi Direct…).
 * Never introduce a second incompatible format — bump `v` instead.
 */
export const MAGELLAN_PAYLOAD_VERSION = 1 as const;
export const MAGELLAN_PAYLOAD_PREFIX = "MGLN";

export const locationPayloadSchema = z.object({
  t: z.literal("MGLN"),
  v: z.literal(1),
  lat: z.number().min(-90).max(90),
  lon: z.number().min(-180).max(180),
  alt: z.number().optional(),
  acc: z.number().nonnegative().optional(),
  ts: z.number().int().nonnegative(),
  name: z.string().max(64).optional(),
  note: z.string().max(160).optional(),
  src: z.enum(["live", "waypoint", "manual", "demo"]).default("demo"),
});

export function encodeLocationPayload(p: LocationPayloadV1): string {
  return JSON.stringify(p);
}

export type DecodeResult =
  | { ok: true; payload: LocationPayloadV1 }
  | { ok: false; error: string };

/** Strict, non-throwing decode. Malformed data is rejected, never guessed. */
export function decodeLocationPayload(raw: string): DecodeResult {
  const text = raw.trim();
  if (!text) return { ok: false, error: "Empty scan result." };
  let json: unknown;
  try {
    json = JSON.parse(text);
  } catch {
    return { ok: false, error: "Not a Magellan payload (invalid JSON)." };
  }
  const obj = json as Record<string, unknown> | null;
  if (!obj || obj["t"] !== MAGELLAN_PAYLOAD_PREFIX)
    return { ok: false, error: "Not a Magellan payload (missing MGLN tag)." };
  if (obj["v"] !== MAGELLAN_PAYLOAD_VERSION)
    return { ok: false, error: `Unsupported payload version: ${String(obj["v"])}.` };
  const parsed = locationPayloadSchema.safeParse(obj);
  if (!parsed.success)
    return { ok: false, error: parsed.error.issues[0]?.message ?? "Invalid payload fields." };
  return { ok: true, payload: parsed.data };
}